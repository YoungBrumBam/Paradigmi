import java.util.ArrayList;

public class Main {
    public ArrayList<agenda> agende;
    public static void main(String[] args) {

    }
}